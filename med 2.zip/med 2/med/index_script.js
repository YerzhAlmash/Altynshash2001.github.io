$(document).ready(function(){
	$('.clinic_name').delay('slow').hide('fast').delay(1000).show(1000)
});

$(document).ready(function(){
	$('.buttons').delay('slow').hide('fast').delay(1000).show(1000)
});
$('.m a').click(function(){
	$('form').animate({height: 'toggle', opacity: "toggle"}, "slow");
});