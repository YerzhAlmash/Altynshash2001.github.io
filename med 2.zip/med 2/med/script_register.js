$(document).ready(function(){
	$('.clinic_name').delay('slow').hide('fast').delay(1000).show(1000)
});
$('.m a').click(function(){
	$('form').animate({height: 'toggle', opacity: "toggle"}, "slow");
});

$(document).ready(function(){
	$('.buttons').delay('slow').hide('fast').delay(1000).show(1000)
});
$('.m a').click(function(){
	$('form').animate({height: 'toggle', opacity: "toggle"}, "slow");
});

//his function shows and hides

$(document).ready(function(){
	$(".login").hide();
	$(".register_li").addClass("active");

	$(".login_li").click(function(){
		$(this).addClass("active");
		$(".register_li").removeClass("active");
		$(".login").show();
		$(".register").hide();
	});
	$(".register_li").click(function(){
		$(this).addClass("active");
		$(".login_li").removeClass("active");
		$(".register").show();
		$(".login").hide();
	});
});


function validation(){
	var username = document.getElementById('username').value;
	var password = document.getElementById('password').value;
	var password2 = document.getElementById('repassword').value;
	var email = document.getElementById('email').value;
	var number = document.getElementById('num').value;

	var check_user = /^[a-zA-Z][a-zA-Z0-9-_\.]{1,21}$/;
	var check_pass = /(?=^.{8,}$)((?=.*\d)|(?=.*\W+))(?![.\n])(?=.*[A-Z])(?=.*[a-z]).*$/;
	var check_email = /^[A-za-z0-9_]{3,}@[A-za-z.]{3,}$/;
	var check_num = /^((8|\+7)[\-]?)?(\(?\d{3}\)?[\-]?)?[\d\-]{11}$/;

	if(check_user.test(username)){
		document.getElementById('uname_error').innerHTML = "";

	}else{
		document.getElementById('uname_error').innerHTML = "Username is required";
		return false;
	}

	if(check_pass.test(password)){
		document.getElementById('pass_error').innerHTML = "";

	}else{
		document.getElementById('pass_error').innerHTML = "Password is required";
		return false;
	}

	if(password===password2){
		document.getElementById('repassword').innerHTML = "";	

	}else{
		document.getElementById('repassword').innerHTML = "Two passwords do not match";
		return false;
	}

	if(check_email.test(email)){
		document.getElementById('email_error').innerHTML = "";

	}else{
		document.getElementById('email_error').innerHTML = "Email is required";
		return false;
    }

	if(check_num.test(number)){
		document.getElementById('number_error').innerHTML = "";

	}else{
		document.getElementById('number_error').innerHTML = "Number is required";
		return false;
	}

}



/*var selectedRow = null;

function onFormSubmit(){
	var form_data = readFormData();
	insertNewRecord(form_data);
}


function readFormData(){
	var form_data={};
	form_data["username"] = document.getElementById('username').value;
	form_data["password"] = document.getElementById('password').value;
	form_data["email"] = document.getElementById('email').value;
	form_data["num"] = document.getElementById('num').value;
	return form_data;

}

function insertNewRecord(data){
	var table = document.getElementById('emlist').getElementsByTagName('tbody')[0];
	var newrow = table.insertRow(table.lenght);
	cell1 = row.insertCell(0);
	cell1.inner.HTML = data.username;
	cell2 = row.insertCell(1);
	cell2.inner.HTML = data.password;
	cell3 = row.insertCell(2);
    cell3.inner.HTML = data.email;
	cell4 = row.insertCell(3);
    cell4.inner.HTML = data.number;
	cell5 = row.insertCell(4);
	cell5.inner.HTML = '<a onClick="onEdit(this)">Edit</a><a>Delete</>';
}
function reset(){
	document.getElementById("username");
	document.getElementById("password");
	document.getElementById("email");
	document.getElementById("num");

}
function onEdit(){
	selectedRow = td.parentElement;
	document.getElementById("username").value = selectedRow.cell[0].innerHTML;
	document.getElementById("password").value = selectedRow.cell[1].innerHTML;
	document.getElementById("email").value = selectedRow.cell[2].innerHTML;
	document.getElementById("num").value = selectedRow.cell[3].innerHTML;
}
function updateRecord(formData) {
    selectedRow.cells[0].innerHTML = formData.username;
    selectedRow.cells[1].innerHTML = formData.password;
    selectedRow.cells[2].innerHTML = formData.email;
    selectedRow.cells[3].innerHTML = formData.number;
}

function onDelete(td) {
    if (confirm('Are you sure to delete this record ?')) {
        row = td.parentElement.parentElement;
        document.getElementById("emlist").deleteRow(row.rowIndex);
        resetForm();
    }*/